%   fb_TSA
%  
%  Source code v1.0
%
%  Main Paper:
%   Jianhua Jiang and Xianqiu Meng and Yunjun Chen and Chunyan Qiu and Yang Liu and Keqin Li,
%   Enhancing tree-seed algorithm via feed-back mechanism for optimizing continuous problems
%   Applied Soft Computing
%   Volume 92,
%   2020,
%   106314,
%   https://doi.org/10.1016/j.asoc.2020.106314
%______________________________________________________________________________________________

clear all 

SearchAgents_no=30; % Number of search agents

Max_iteration=500; % Maximum numbef of iterations

seeds_lb=ceil(SearchAgents_no*0.1);% upper limit of seed's number
seeds_ub=ceil(SearchAgents_no*0.25);% lower limit of seed's number

ST=0.1;
run_time_of_each=zeros(23,50);%The time of each run
run_results=zeros(23,50);%The results of each run

for f=21:23
    Function_name=strcat('F',num2str(f)); % Name of the test function that can be from F1 to F23
    for i=1:1

    [lb,ub,dim,fobj]=Get_Functions_details(Function_name);% Load details of the selected benchmark function
   [Best_score1,Best_pos1,cg_curve1,time]=fb_tsa(SearchAgents_no,Max_iteration,lb,ub,dim,fobj); % call fb_TSA algorithm

    run_results(f,i)=Best_score1;
    run_time_of_each=time;
    


    display(['The best optimal value of the objective funciton found by fb_TSA is : ', num2str(Best_score1)]);
    end;
end;



