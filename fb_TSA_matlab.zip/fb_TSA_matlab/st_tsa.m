%  st_tsa
%  
%  Source code v1.0
%
%  Main Paper:
%   Jianhua Jiang and Xianqiu Meng and Yunjun Chen and Chunyan Qiu and Yang Liu and Keqin Li,
%   Enhancing tree-seed algorithm via feed-back mechanism for optimizing continuous problems
%   Applied Soft Computing
%   Volume 92,
%   2020,
%   106314,
%   https://doi.org/10.1016/j.asoc.2020.106314
%______________________________________________________________________________________________

function [gbestval,gbest,convergence,fitcount]= st_tsa(N,Max_iteration,lb,ub,dim,fobj)

low=ceil(0.1*N);          % is used by determining the number of seeds produced for a tree
high=ceil(0.25*N);        % is used by determining the number of seeds produced for a tree
D= dim; % Dimensionality of the problem
ST = 0.1*ones(1,N);           % Search tendency parameter used for equation selection
dmin=ub;        % The lower bound of search space
dmax=lb;         % The upper bound of search space

fes=N;              % is the fes counter.
max_fes=500000;    % is the termination condition 

trees=zeros(N,D);    % tree population
obj=zeros(1,N);      % objective function value for each tree

t=1;
convergence = ones(1,Max_iteration);

for i=1:N
    for j=1:D
        trees(i,j)=dmin+(dmax-dmin)*rand;   % The trees location on the search space
    end
    obj(i)=fobj(trees(i,:));
end


%%% The determination of best tree location in the stand
[values,indis]=min(obj);
indis=indis(end);
best=obj(indis);
best_params=trees(indis,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  while  (t <= Max_iteration) 
%%%%%%%%%%%%%%%%%%   SEED PRODUCTION   %%%%%%%%%%%%%%%%%%
     for i=1:N
            ns=low+randi(high-low+1)-1; % Number of seeds for this tree
            ns=ns(1);
            seeds=zeros(ns,D);
            objs=zeros(1,ns);
            for j=1:ns
                % Determination of the neighbour for ith tree.    
                   r=fix(rand*N)+1;
                   while(i==r)
                        r=fix(rand*N)+1;
                   end
                %%% SEEDS ARE CREATING
                for d=1:D
%                     if (ns(i)==nSeedsLow)                   
%                         seeds(j,d)=trees(r,d)+(trees(i,d)-trees(r,d))*(rand-0.5)*2;
%                         if(seeds(j,d)>dmax || seeds(j,d)<dmin)
%                         seeds(j,d)=dmin+(dmax-dmin)*rand;
%                         end
%                     else           
                        if(rand<ST(i))
                            seeds(j,d)=trees(i,d)+(best_params(d)-trees(r,d))*(rand-0.5)*2;
                            if(seeds(j,d)>dmax || seeds(j,d)<dmin)
                                seeds(j,d)=dmin+(dmax-dmin)*rand;
                            end
                        else
                            seeds(j,d)=trees(i,d)+(trees(r,d)-trees(i,d))*(rand-0.5)*2;
                            if(seeds(j,d)>dmax || seeds(j,d)<dmin)
                                seeds(j,d)=dmin+(dmax-dmin)*rand;
                            end
                        end

                end
                  objs(j)=fobj(seeds(j,:));
            end 
            
            
            fes=fes+ns;
            
            [val,indis]=min(objs);
            indis=indis(end);


            if(objs(indis)>=obj(i)) 
                ST(i)=ST(i)+0.02; %, see Eq. (8) in our paper
                if ST(i)>0.12
                    ST(i)=0.1;
                end
            else 
                 ST(i)=ST(i)-0.04;%, see Eq. (9) in our paper
                 if ST(i)<0 
                     ST(i)=0.1;
                 end
                trees(i,:)=seeds(indis,:); 
                obj(i)=fobj(trees(i,:));
            end          
          
             if(t==300)
                 a=100;
             end  
         
            clear objs;
            clear seeds;            
     end

        %%% The determination of best tree location obtained so far.
        [values,indis]=min(obj);
        indis=indis(end);
        temp_best=obj(indis);   
        if(temp_best<best)
            best=temp_best;
            best_params=trees(indis,:);
        end
        convergence(t)=best;
        t=t+1;
  end
    gbest = best_params; 
    gbestval =best; 
    fitcount=fes;
end









